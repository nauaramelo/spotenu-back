"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BandDatabase = void 0;
const UserDatabase_1 = require("./UserDatabase");
const Band_1 = require("../model/Band");
const User_1 = require("../model/User");
class BandDatabase extends UserDatabase_1.UserDatabase {
    toModel(dbModel) {
        return (dbModel &&
            new Band_1.Band(dbModel.id, dbModel.email, dbModel.name, dbModel.nickname, dbModel.password, dbModel.role, dbModel.description, this.convertTinyintToBoolean(dbModel.is_active)));
    }
    createUserBand(band) {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.getConnection.call(this).raw(`
      INSERT INTO ${this.tableName} (id, name, nickname, email, password, role, description, is_active)
        VALUES (
        '${band.getId()}',
        '${band.getName()}',
        '${band.getNickname()}',
        '${band.getEmail()}',
        '${band.getPassword()}',
        '${band.getRole()}',
        '${band.getDescription()}',
        '${this.convertBooleanToTinyint(band.getIsActive())}'
      )
    `);
        });
    }
    ;
    getAllBands() {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.getConnection.call(this).raw(`
      SELECT * from ${this.tableName} WHERE role = '${User_1.UserRole.BAND}'
    `);
            return result[0].map((band) => {
                return this.toModel(band);
            });
        });
    }
    getBandById(id) {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.getConnection.call(this).raw(`
      SELECT * from ${this.tableName} WHERE id = '${id}'
    `);
            return this.toModel(result[0][0]);
        });
    }
    approveBand(id) {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.getConnection.call(this).raw(`
      UPDATE ${this.tableName} SET is_active = ${this.convertBooleanToTinyint(true)} WHERE id = '${id}'
    `);
        });
    }
}
exports.BandDatabase = BandDatabase;
