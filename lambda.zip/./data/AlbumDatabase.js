"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumDatabase = void 0;
const Album_1 = require("../model/Album");
const BaseDatabase_1 = require("./BaseDatabase");
class AlbumDatabase extends BaseDatabase_1.BaseDataBase {
    constructor() {
        super(...arguments);
        this.tableName = "SpotenuAlbums";
    }
    toModel(dbModel) {
        return (dbModel &&
            new Album_1.Album(dbModel.id, dbModel.name, dbModel.id_band));
    }
    createAlbum(album) {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.getConnection.call(this).raw(`
          INSERT INTO ${this.tableName} (id, name, id_band)
            VALUES(
                '${album.getId()}',
                '${album.getName()}',
                '${(_a = album.getBand()) === null || _a === void 0 ? void 0 : _a.getId()}'
            )
        `);
        });
    }
    findById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield this.getConnection().raw(`
            SELECT * FROM ${this.tableName} where id = '${id}'
        `);
            return this.toModel(result[0][0]);
        });
    }
    getAllAlbums() {
        const _super = Object.create(null, {
            getConnection: { get: () => super.getConnection }
        });
        return __awaiter(this, void 0, void 0, function* () {
            const result = yield _super.getConnection.call(this).raw(`
            SELECT * FROM ${this.tableName} 
        `);
            return result[0];
        });
    }
}
exports.AlbumDatabase = AlbumDatabase;
