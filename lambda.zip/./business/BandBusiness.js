"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BandBusiness = void 0;
const Band_1 = require("../model/Band");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const NotFoundError_1 = require("../errors/NotFoundError");
const GenericError_1 = require("../errors/GenericError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const User_1 = require("../model/User");
class BandBusiness {
    constructor(bandDatabase, tokenGenerator, hashGenerator, idGenerator) {
        this.bandDatabase = bandDatabase;
        this.tokenGenerator = tokenGenerator;
        this.hashGenerator = hashGenerator;
        this.idGenerator = idGenerator;
    }
    signupUserBand(name, nickname, email, description, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !nickname || !email || !password || !description) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid email");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid password");
            }
            const id = this.idGenerator.generate();
            const cryptedPassword = yield this.hashGenerator.hash(password);
            const isActive = false;
            const userBand = new Band_1.Band(id, email, name, nickname, cryptedPassword, User_1.UserRole.BAND, description, isActive);
            yield this.bandDatabase.createUserBand(userBand);
            return userBand;
        });
    }
    getAllBands() {
        return __awaiter(this, void 0, void 0, function* () {
            const bands = yield this.bandDatabase.getAllBands();
            return bands.map((band) => {
                return this.toInterfaceResultBand(band);
            });
        });
    }
    toInterfaceResultBand(band) {
        return {
            id: band.getId(),
            name: band.getName(),
            nickname: band.getNickname(),
            email: band.getEmail(),
            isActive: band.getIsActive()
        };
    }
    userBandIsActive(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const band = yield this.bandDatabase.getBandById(id);
            return (band === null || band === void 0 ? void 0 : band.getIsActive()) === true;
        });
    }
    approveBand(id, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const band = yield this.bandDatabase.getBandById(id);
            if (!band) {
                throw new NotFoundError_1.NotFoundError("Band not found");
            }
            if (band.getIsActive()) {
                throw new GenericError_1.GenericError("This band is already approved");
            }
            if (this.tokenGenerator.verify(token).role !== User_1.UserRole.ADMIN) {
                throw new UnauthorizedError_1.UnauthorizedError("You must be an admin to access this information");
            }
            yield this.bandDatabase.approveBand(id);
        });
    }
}
exports.BandBusiness = BandBusiness;
