"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumBusiness = void 0;
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const User_1 = require("../model/User");
const Genre_1 = require("../model/Genre");
const Album_1 = require("../model/Album");
const Band_1 = require("../model/Band");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
class AlbumBusiness {
    constructor(tokenGenerator, albumDatabase, albumGenreDatabase, idGenerator) {
        this.tokenGenerator = tokenGenerator;
        this.albumDatabase = albumDatabase;
        this.albumGenreDatabase = albumGenreDatabase;
        this.idGenerator = idGenerator;
    }
    addAlbum(name, genres, token) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const id = this.idGenerator.generate();
            const payload = this.tokenGenerator.verify(token);
            if (!name || !genres) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            if (payload.role !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("You must be an band to access this information");
            }
            const album = new Album_1.Album(id, name, genres.map((genre) => new Genre_1.Genre(genre)), new Band_1.Band(payload.id));
            yield this.albumDatabase.createAlbum(album);
            (_a = album.getGenres()) === null || _a === void 0 ? void 0 : _a.forEach((genre) => __awaiter(this, void 0, void 0, function* () {
                yield this.albumGenreDatabase.createAlbumWithGenres(album.getId(), genre.getId());
            }));
        });
    }
    getById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.albumDatabase.findById(id);
        });
    }
    getAlbums(token) {
        return __awaiter(this, void 0, void 0, function* () {
            const role = this.tokenGenerator.verify(token).role;
            if (role !== User_1.UserRole.ADMIN && role !== User_1.UserRole.BAND) {
                throw new UnauthorizedError_1.UnauthorizedError("You must be an band to access this information");
            }
            const albums = yield this.albumDatabase.getAllAlbums();
            return albums;
        });
    }
}
exports.AlbumBusiness = AlbumBusiness;
