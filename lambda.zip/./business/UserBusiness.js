"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserBusiness = void 0;
const User_1 = require("../model/User");
const NotFoundError_1 = require("../errors/NotFoundError");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const UnauthorizedError_1 = require("../errors/UnauthorizedError");
const ConflitError_1 = require("../errors/ConflitError");
class UserBusiness {
    constructor(userDatabase, hashGenerator, tokenGenerator, idGenerator, bandBusiness) {
        this.userDatabase = userDatabase;
        this.hashGenerator = hashGenerator;
        this.tokenGenerator = tokenGenerator;
        this.idGenerator = idGenerator;
        this.bandBusiness = bandBusiness;
    }
    signupListener(name, nickname, email, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !nickname || !email || !password) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid email");
            }
            if (password.length < 6) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid password");
            }
            const checkUserExists = yield this.userDatabase.getUserByEmailOrNickname(email, nickname);
            if (checkUserExists) {
                throw new ConflitError_1.ConflitError("User already registered");
            }
            const id = this.idGenerator.generate();
            const role = User_1.UserRole.LISTENER_NO_PAYING;
            const cryptedPassword = yield this.hashGenerator.hash(password);
            yield this.userDatabase.createUser(new User_1.User(id, name, nickname, email, cryptedPassword, role));
            const accessToken = this.tokenGenerator.generate({
                id,
                role,
            });
            return { accessToken, role };
        });
    }
    signupAdmin(name, nickname, email, password, token) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!name || !nickname || !email || !password) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            if (email.indexOf("@") === -1) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid email");
            }
            if (password.length < 10) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid password");
            }
            const checkUserExists = yield this.userDatabase.getUserByEmailOrNickname(email, nickname);
            if (checkUserExists) {
                throw new ConflitError_1.ConflitError("User already registered");
            }
            if (this.tokenGenerator.verify(token).role !== User_1.UserRole.ADMIN) {
                throw new UnauthorizedError_1.UnauthorizedError("You must be an admin to access this information");
            }
            const id = this.idGenerator.generate();
            const cryptedPassword = yield this.hashGenerator.hash(password);
            const user = new User_1.User(id, name, nickname, email, cryptedPassword, User_1.UserRole.ADMIN);
            yield this.userDatabase.createUser(user);
            return user;
        });
    }
    login(nicknameOrEmail, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!nicknameOrEmail || !password) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            const user = yield this.userDatabase.getUserByEmailOrNickname(nicknameOrEmail, nicknameOrEmail);
            if (!user) {
                throw new NotFoundError_1.NotFoundError("User not found");
            }
            if ((user === null || user === void 0 ? void 0 : user.getRole()) === User_1.UserRole.BAND && !(yield this.bandBusiness.userBandIsActive(user.getId()))) {
                throw new UnauthorizedError_1.UnauthorizedError("You are not authorized to access");
            }
            const isPasswordCorrect = yield this.hashGenerator.compareHash(password, user.getPassword());
            if (!isPasswordCorrect) {
                throw new InvalidParameterError_1.InvalidParameterError("Invalid password");
            }
            const accessToken = this.tokenGenerator.generate({
                id: user.getId(),
                role: user.getRole(),
            });
            return { accessToken, role: user.getRole() };
        });
    }
}
exports.UserBusiness = UserBusiness;
