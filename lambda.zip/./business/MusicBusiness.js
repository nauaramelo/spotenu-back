"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicBusiness = void 0;
const ConflitError_1 = require("../errors/ConflitError");
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
const AlbumBusiness_1 = require("./AlbumBusiness");
const NotFoundError_1 = require("../errors/NotFoundError");
const Music_1 = require("../model/Music");
const AlbumDatabase_1 = require("../data/AlbumDatabase");
const AlbumGenreDatabase_1 = require("../data/AlbumGenreDatabase");
class MusicBusiness {
    constructor(tokenGenerator, musicDatabase, idGenerator) {
        this.tokenGenerator = tokenGenerator;
        this.musicDatabase = musicDatabase;
        this.idGenerator = idGenerator;
        this.albumBusiness = new AlbumBusiness_1.AlbumBusiness(tokenGenerator, new AlbumDatabase_1.AlbumDatabase(), new AlbumGenreDatabase_1.AlbumGenreDatabase(), idGenerator);
    }
    createMusic(name, idAlbum, token) {
        return __awaiter(this, void 0, void 0, function* () {
            const id = this.idGenerator.generate();
            this.tokenGenerator.verify(token);
            if (!name || !idAlbum) {
                throw new InvalidParameterError_1.InvalidParameterError("Missing input");
            }
            const album = yield this.albumBusiness.getById(idAlbum);
            if (!album) {
                throw new NotFoundError_1.NotFoundError("Album not found");
            }
            const musicFound = yield this.musicDatabase.findByNameAndIdAlbum(name, idAlbum);
            if (musicFound) {
                throw new ConflitError_1.ConflitError("Music already registered in this album");
            }
            yield this.musicDatabase.createMusic(new Music_1.Music(id, name, album));
        });
    }
}
exports.MusicBusiness = MusicBusiness;
