"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumRouter = void 0;
const express_1 = __importDefault(require("express"));
const AlbumController_1 = require("../controller/AlbumController");
exports.albumRouter = express_1.default.Router();
exports.albumRouter.post("/add", new AlbumController_1.AlbumController().addGenre);
exports.albumRouter.get("/all", new AlbumController_1.AlbumController().getAlbums);
