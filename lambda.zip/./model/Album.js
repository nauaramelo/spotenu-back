"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Album = void 0;
class Album {
    constructor(id, name, genres, band) {
        this.id = id;
        this.name = name;
        this.genres = genres;
        this.band = band;
    }
    getId() {
        return this.id;
    }
    getName() {
        return this.name;
    }
    getGenres() {
        return this.genres;
    }
    getBand() {
        return this.band;
    }
}
exports.Album = Album;
