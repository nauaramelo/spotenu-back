"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRole = exports.stringToUserRole = exports.User = void 0;
const InvalidParameterError_1 = require("../errors/InvalidParameterError");
class User {
    constructor(id, name, nickname, email, password, role) {
        this.id = id;
        this.name = name;
        this.nickname = nickname;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    getId() {
        return this.id;
    }
    getName() {
        return this.name;
    }
    getNickname() {
        return this.nickname;
    }
    getEmail() {
        return this.email;
    }
    getPassword() {
        return this.password;
    }
    getRole() {
        return this.role;
    }
}
exports.User = User;
exports.stringToUserRole = (input) => {
    switch (input) {
        case "BAND":
            return UserRole.BAND;
        case "LISTENER_NO_PAYING":
            return UserRole.LISTENER_NO_PAYING;
        case "LISTENER_PAYING":
            return UserRole.LISTENER_PAYING;
        case "ADMIN":
            return UserRole.ADMIN;
        default:
            throw new InvalidParameterError_1.InvalidParameterError("Invalid user role");
    }
};
var UserRole;
(function (UserRole) {
    UserRole["BAND"] = "BAND";
    UserRole["LISTENER_NO_PAYING"] = "LISTENER_NO_PAYING";
    UserRole["LISTENER_PAYING"] = "LISTENER_PAYING";
    UserRole["ADMIN"] = "ADMIN";
})(UserRole = exports.UserRole || (exports.UserRole = {}));
