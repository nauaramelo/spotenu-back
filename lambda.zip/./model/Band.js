"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Band = void 0;
const User_1 = require("./User");
class Band extends User_1.User {
    constructor(id, email, name, nickname, password, role, description, isActive) {
        super(id, name, nickname, email, password, role);
        this.description = description;
        this.isActive = isActive;
    }
    getDescription() {
        return this.description;
    }
    getIsActive() {
        return this.isActive;
    }
}
exports.Band = Band;
