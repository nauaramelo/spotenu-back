"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const UserRouter_1 = require("./router/UserRouter");
const BandRouter_1 = require("./router/BandRouter");
const GenreRouter_1 = require("./router/GenreRouter");
const AlbumRouter_1 = require("./router/AlbumRouter");
const MusicRouter_1 = require("./router/MusicRouter");
const cors_1 = __importDefault(require("cors"));
const app = express_1.default();
app.use(cors_1.default());
app.use(express_1.default.json());
app.use("/users/", UserRouter_1.userRouter);
app.use("/bands/", BandRouter_1.bandRouter);
app.use("/genres", GenreRouter_1.genreRouter);
app.use("/albums", AlbumRouter_1.albumRouter);
app.use("/musics", MusicRouter_1.musicRouter);
exports.default = app;
/*
const server = app.listen(3001, () => {
  if (server) {
    const address = server.address() as AddressInfo;
    console.log(`Servidor rodando em http://localhost:${address.port}`);
  } else {
    console.error(`Falha ao rodar o servidor.`);
  }
}); */ 
