"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConflitError = void 0;
const BaseError_1 = require("./BaseError/BaseError");
class ConflitError extends BaseError_1.BaseError {
    constructor(message) {
        super(message, 409);
    }
}
exports.ConflitError = ConflitError;
