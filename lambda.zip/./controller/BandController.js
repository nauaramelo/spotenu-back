"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BandController = void 0;
const BandBusiness_1 = require("../business/BandBusiness");
const BandDatabase_1 = require("../data/BandDatabase");
const tokenGenerator_1 = require("../services/tokenGenerator");
const hashGenerator_1 = require("../services/hashGenerator");
const idGenerator_1 = require("../services/idGenerator");
class BandController {
    signupUserBand(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield BandController.BandBusiness.signupUserBand(req.body.name, req.body.nickname, req.body.email, req.body.description, req.body.password);
                res.status(200).send({ message: "Banda cadastrada!" });
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    getAllBands(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const bands = yield BandController.BandBusiness.getAllBands();
                res.status(200).send({ bands });
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    aprroveBand(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const id = req.params.id;
                const token = req.headers.authorization || req.headers.Authorization;
                const result = yield BandController.BandBusiness.approveBand(id, token);
                res.status(200).send({ message: "Aproved band" });
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.BandController = BandController;
BandController.BandBusiness = new BandBusiness_1.BandBusiness(new BandDatabase_1.BandDatabase(), new tokenGenerator_1.TokenGenerator(), new hashGenerator_1.HashGenerator(), new idGenerator_1.IdGenerator());
