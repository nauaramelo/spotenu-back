"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const UserBusiness_1 = require("../business/UserBusiness");
const tokenGenerator_1 = require("../services/tokenGenerator");
const UserDatabase_1 = require("../data/UserDatabase");
const hashGenerator_1 = require("../services/hashGenerator");
const idGenerator_1 = require("../services/idGenerator");
const BandBusiness_1 = require("../business/BandBusiness");
const BandDatabase_1 = require("../data/BandDatabase");
class UserController {
    signupListener(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield UserController.UserBusiness.signupListener(req.body.name, req.body.nickname, req.body.email, req.body.password);
                res.status(200).send(result);
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    signupAdmin(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield UserController.UserBusiness.signupAdmin(req.body.name, req.body.nickname, req.body.email, req.body.password, req.headers.authorization || req.headers.Authorization);
                res.status(200).send({ message: "Registered Administrator" });
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
    login(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            const nicknameOrEmail = req.body.nicknameOrEmail;
            const password = req.body.password;
            try {
                const result = yield UserController.UserBusiness.login(nicknameOrEmail, password);
                res.status(200).send(result);
            }
            catch (err) {
                res.status(err.errorCode || 400).send({ message: err.message });
            }
        });
    }
}
exports.UserController = UserController;
UserController.UserBusiness = new UserBusiness_1.UserBusiness(new UserDatabase_1.UserDatabase(), new hashGenerator_1.HashGenerator(), new tokenGenerator_1.TokenGenerator(), new idGenerator_1.IdGenerator(), new BandBusiness_1.BandBusiness(new BandDatabase_1.BandDatabase(), new tokenGenerator_1.TokenGenerator(), new hashGenerator_1.HashGenerator, new idGenerator_1.IdGenerator));
